#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{

  if(argc != 1){
    fprintf(2, "usage: %s\n", argv[0]);
    exit(1);
  }

  int oldticks = 0;
  while ( 1 ) {
    int upticks = uptime();
    if ( upticks != oldticks ) {
      for ( int i = 0 ; i < upticks - oldticks ; i++ ) {
        printf(".");
      }
      oldticks = upticks;
    }
  }

}
