#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char **argv) {
  // Set up the pipes
  int pwtoparent[2];
  int pwtochild[2];
 
  // I want the parent to send the message down the pipe to the child,
  // the clind must wait to read that message and then send the message to the parent who
  // waits for the message from the child

  // Analogy: Someone is stuck down a well and you yell down to them (the child) and wait to he
  // ar a response. Ping Pong I guess is another one lol.

  // 0 Is the reading end of the pipe, 1 is the writing end of the pipe
  pipe(pwtoparent);
  pipe(pwtochild);
  int pid = fork();
  // if fork is 0, then this is the child process
  
  if (pid != 0) {
    char byte[1];
    write(pwtochild[1], " ", 1);
    read(pwtoparent[0], byte, 1);
    printf("%d: received pong\n", getpid()); 
    close(pwtoparent[1]);
    close(pwtoparent[0]);
  } else {
    char byte[1];
    read(pwtochild[0], byte, 1);
    printf("%d: received ping\n", getpid());
    write(pwtoparent[1], " ", 1);
    close(pwtochild[1]);
    close(pwtochild[0]);
  }
  exit(0);
}  
